return {
  name         = "Damage to Chat",
  description  = "Automatically reports players damage to chat at mission end.",
  is_togglable = true,
  options      = { widgets = {} }
}
