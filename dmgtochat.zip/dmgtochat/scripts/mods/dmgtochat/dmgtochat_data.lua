local mod = get_mod("dmgtochat")

-- human‐readable level names, indexed by their internal value
local LEVEL_NAMES = {
  [0]  = "Off",
  [1]  = "Sedition",
  [2] = "Uprising",
  [3] = "Malice",
  [4] = "Heresy",
  [5] = "Damnation",
  [6] = "Malice Maelstrom",
  [7] = "Heresy Maelstrom",
  [8] = "Damnation Maelstrom",
  [9] = "Auric Heresy",
  [10] = "Auric Damnation",
  [11] = "Auric Maelstrom",
  [12] = "Havoc ranks 1–10 (Malice)",
  [13] = "Havoc ranks 11–20 (Heresy)",
  [14] = "Havoc ranks 21–40 (Damnation)",
  [15] = "Off",
}

return {
  name         = mod:localize("mod_name"),
  description  = mod:localize("mod_description"),
  is_togglable = true,
  options      = {
    widgets = {
      {
        setting_id    = "mod_operative",
        type          = "checkbox",
        default_value = true,
        text          = "mod_operative",
        tooltip       = "mod_operative_desc",
      },
      {
        setting_id    = "make_verbose",
        type          = "checkbox",
        default_value = false,
        text          = "make_verbose",
        tooltip       = "make_verbose_desc",
      },
      {
        setting_id    = "colored_output",
        type          = "checkbox",
        default_value = false,
        text          = "colored_output",
        tooltip       = "colored_output_desc",
      },
      {
        setting_id = "mod_limiter",
        type       = "group",
        text       = "mod_limiter",
        sub_widgets = {
          {
            setting_id    = "min_limit",
            type          = "dropdown",
            default_value = 0,
            text          = "min_limit",
            tooltip       = "min_limit_desc",
            options = (function()
              local o = {}
              for i = 0, 14 do
                o[#o+1] = { text = LEVEL_NAMES[i], value = i }
              end
              return o
            end)()
          },
          {
            setting_id    = "max_limit",
            type          = "dropdown",
            default_value = 15,
            text          = "max_limit",
            tooltip       = "max_limit_desc",
            options = (function()
              local o = {}
              for i = 2, 14 do
                o[#o+1] = { text = LEVEL_NAMES[i], value = i }
              end
              o[#o+1] = { text = LEVEL_NAMES[15], value = 15 }
              return o
            end)()
          },
          {
            setting_id    = "echo_vox",
            type          = "checkbox",
            default_value = false,
            text          = "echo_vox",
            tooltip       = "echo_vox_desc",
          },
        }
      },
    }
  }
}
