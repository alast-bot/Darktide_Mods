-- mods/dmgtochat/scripts/mods/dmgtochat/dmgtochat_data.lua
local mod = get_mod("dmgtochat")

return {
  name         = mod:localize("mod_name"),
  description  = mod:localize("mod_description"),
  is_togglable = true,
  options      = {
    widgets = {
      {
        setting_id    = "mod_operative",
        type          = "checkbox",
        default_value = true,
        tooltip       = "mod_operative_desc",
      },
      {
        setting_id    = "make_verbose",
        type          = "checkbox",
        default_value = false,
        tooltip       = "make_verbose_desc",
      },
      {
        setting_id    = "colored_output",
        type          = "checkbox",
        default_value = false,
        tooltip       = "colored_output_desc",
      },
    }
  }
}
