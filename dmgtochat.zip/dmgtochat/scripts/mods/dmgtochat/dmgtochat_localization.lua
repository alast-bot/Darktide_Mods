-- mods/dmgtochat/scripts/mods/dmgtochat/dmgtochat_localization.lua
local mod = get_mod("dmgtochat")

local loc = {
  mod_name = {
    en = "Damage to Chat",
  },
  mod_description = {
    en = "Reports each player’s total and boss damage to the chat at mission end.",
  },

  mod_operative = {
    en = "Mod Active",
  },
  mod_operative_desc = {
    en = "On to report damage; Off to disable the mod (even while in mission)",
  },

  make_verbose = {
    en = "Verbose Output",
  },
  make_verbose_desc = {
    en = "Reports on 2 chat lines; Off uses just 1",
  },

  colored_output = {
    en = "Coloured Output",
  },
  colored_output_desc = {
    en = "Orange report text; Off leaves it white",
  },
}

return loc
