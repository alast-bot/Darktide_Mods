-- dmgtochat_localization.lua
local mod = get_mod("dmgtochat")

local loc = {
  mod_name = {
    en = "Damage to Chat",
  },
  mod_description = {
    en = "Reports each player’s total damage to the chat at mission end.",
  },

  mod_operative = {
    en = "Mod Engaged",
  },
  mod_operative_desc = {
    en = "On to report damage; Off to disable the mod (even while in mission)",
  },

  make_verbose = {
    en = "Verbose Broadcast",
  },
  make_verbose_desc = {
    en = "Reports on two chat lines; Off uses just one",
  },

  colored_output = {
    en = "Chromatic Cant",
  },
  colored_output_desc = {
    en = "Orange report text; Off leaves it white",
  },

  mod_limiter = {
    en = "Mod Constraints",
  },

  min_limit = {
    en = "Min Combat Theatre",
  },
  min_limit_desc = {
    en = "Minimum level where the mod is operational. Off means no minimum. Cannot be greater than Max Combat Theatre.",
  },

  max_limit = {
    en = "Max Combat Theatre",
  },
  max_limit_desc = {
    en = "Maximum level where the mod is operational. Off means no maximum. Cannot be less than Min Combat Theatre.",
  },

  echo_vox = {
    en = "EchoVox",
  },
  echo_vox_desc = {
    en = "Mod output to user only, not the rest of the strike team.",
  },

  -- explicit localization for every dropdown key
  Off =                      { en = "Off" },
  Sedition =                 { en = "Sedition" },
  Uprising =                 { en = "Uprising" },
  Malice =                   { en = "Malice" },
  Heresy =                   { en = "Heresy" },
  Damnation =                { en = "Damnation" },
  ["Malice Maelstrom"] =     { en = "Malice Maelstrom" },
  ["Heresy Maelstrom"] =     { en = "Heresy Maelstrom" },
  ["Damnation Maelstrom"] =  { en = "Damnation Maelstrom" },
  ["Auric Heresy"] =         { en = "Auric Heresy" },
  ["Auric Damnation"] =      { en = "Auric Damnation" },
  ["Auric Maelstrom"] =      { en = "Auric Maelstrom" },
  ["Havoc ranks 1–10 (Malice)"]  = { en = "Havoc ranks 1–10 (Malice)" },
  ["Havoc ranks 11–20 (Heresy)"] = { en = "Havoc ranks 11–20 (Heresy)" },
  ["Havoc ranks 21–40 (Damnation)"] = { en = "Havoc ranks 21–40 (Damnation)" },
}

return loc
