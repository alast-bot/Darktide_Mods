return {
  en = {
    mod_name        = " Damage to Chat",
    mod_description = "Automatically reports players damage to chat at mission end."
  }
}
