-- mods/dmgtochat/scripts/mods/dmgtochat/dmgtochat.lua
local mod = get_mod("dmgtochat")

-- Friendly orange tint
local ORANGE_START = "{#color(245,121,21)}"
local ORANGE_END   = "{#reset()}"

-- Prefix icon
local PREFIX_ICON = ""

-- persistent storage
mod._memory = mod:persistent_table("dmgtochat")
mod._memory.channel_handle = nil
mod._memory.sent_report   = false

-- ensure we only fire once per mission
local cutscene_seen = {}

-- reset at mission start
mod:hook_safe("StateGameplay", "on_enter", function()
  mod._memory.sent_report = false
  cutscene_seen = {}
end)

-- capture the chat channel
local function grab_channel(self, channel_handle)
  mod._memory.channel_handle = channel_handle or self._selected_channel_handle
end
mod:hook_safe("ConstantElementChat", "_on_connect_to_channel",         grab_channel)
mod:hook_safe("ConstantElementChat", "_on_disconnect_from_channel",    grab_channel)
mod:hook_safe("ConstantElementChat", "_next_connected_channel_handle", grab_channel)

-- build & send the damage report
local function send_scoreboard_damage()
  -- 1) global on/off
  if not mod:get("mod_operative") then
    return
  end

  -- 2) only once
  if mod._memory.sent_report then
    return
  end

  local chan = mod._memory.channel_handle
  if not chan then
    return
  end

  -- 3) pull in scoreboard rows from the Scoreboard mod
  local sb = get_mod("scoreboard")
  if not sb or not sb.registered_scoreboard_rows then
    return
  end

  local actual_row, boss_row
  for _, row in ipairs(sb.registered_scoreboard_rows) do
    if row.name == "actual_damage_dealt" then
      actual_row = row
    elseif row.name == "boss_damage_dealt" then
      boss_row = row
    end
    if actual_row and boss_row then break end
  end
  if not actual_row or not actual_row.data then
    return
  end

  -- 4) collate each human player's total = actual + boss
  local entries = {}
  for _, player in pairs(Managers.player:players()) do
    if player:is_human_controlled() then
      local id    = player:account_id() or player:name()
      local a     = actual_row.data[id] and actual_row.data[id].score or 0
      local b     = boss_row and boss_row.data and boss_row.data[id] and boss_row.data[id].score or 0
      local total = a + b

      -- 3-letter tag + class icon
      local tag = string.sub(player:name(),1,3)
      local ico = ""
      if player._profile and player._profile.archetype then
        ico = ({
          veteran = "",
          zealot  = "",
          psyker  = "",
          ogryn   = "",
        })[player._profile.archetype.name] or ""
      end

      entries[#entries+1] = { total = total, tag = tag, icon = ico }
    end
  end

  -- 5) sort descending
  table.sort(entries, function(x,y)
    if x.total ~= y.total then
      return x.total > y.total
    else
      return x.tag < y.tag
    end
  end)

  -- 6) format each as "IconTAG #"
  local parts = {}
  for _, e in ipairs(entries) do
    parts[#parts+1] = string.format("%s%s %s", e.icon, e.tag, sb:shorten_value(e.total))
  end
  local parts_str = table.concat(parts, " ")

  -- 7) options: verbose vs compact, coloured vs white
  local coloured = mod:get("colored_output")
  local verbose  = mod:get("make_verbose")

  if verbose then
    -- line A → always white
    Managers.chat:send_channel_message(chan, PREFIX_ICON .. " Report from Damage to Chat mod:")
    -- line B → payload, coloured if requested
    local line2 = parts_str
    if coloured then
      line2 = ORANGE_START .. line2 .. ORANGE_END
    end
    Managers.chat:send_channel_message(chan, line2)
  else
    -- single line
    local msg = PREFIX_ICON .. "Damage to Chat mod: " .. parts_str
    if coloured then
      msg = ORANGE_START .. msg .. ORANGE_END
    end
    Managers.chat:send_channel_message(chan, msg)
  end

  mod._memory.sent_report = true
end

-- hook outro cinematic (fires twice; use our seen-guard)
mod:hook_safe("CinematicSceneExtension", "setup_from_component", function(self)
  local name = self._cinematic_name or ""
  if name == "outro_win" or name == "outro_fail" then
    if cutscene_seen[name] then
      send_scoreboard_damage()
    else
      cutscene_seen[name] = true
    end
  end
end)
