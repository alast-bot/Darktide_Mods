-- mods/dmgtochat/scripts/mods/dmgtochat/dmgtochat.lua

local mod = get_mod("dmgtochat")

-- class icon map
local ICONS = {
  veteran = "",  -- Sharpshooter/Veteran
  zealot  = "",  -- Zealot/Preacher
  psyker  = "",  -- Psyker/Psykinetic
  ogryn   = "",  -- Ogryn/Skullbreaker
}

-- Persistent memory
mod._memory = mod:persistent_table("dmgtochat")
mod._memory.channel_handle = nil
mod._memory.sent_report   = false

-- Track outro
local cutscene_seen = {}

-- Reset flags at mission start
mod:hook_safe("StateGameplay", "on_enter", function()
  mod._memory.sent_report = false
  cutscene_seen = {}
end)

-- Capture chat channel handle
local function get_channel_handle(self, channel_handle)
  mod._memory.channel_handle = channel_handle or self._selected_channel_handle
end

mod:hook_safe("ConstantElementChat", "_on_connect_to_channel",         get_channel_handle)
mod:hook_safe("ConstantElementChat", "_on_disconnect_from_channel",    get_channel_handle)
mod:hook_safe("ConstantElementChat", "_next_connected_channel_handle", get_channel_handle)

-- Build and send the report using Scoreboard’s data
local function send_scoreboard_damage()
  if mod._memory.sent_report then
    return
  end

  local chan = mod._memory.channel_handle
  if not chan then
    return
  end

  local sb = get_mod("scoreboard")
  if not sb or not sb.registered_scoreboard_rows then
    return
  end

  -- Find the two rows of scores
  local actual_row, boss_row
  for _, row in ipairs(sb.registered_scoreboard_rows) do
    if row.name == "actual_damage_dealt" then
      actual_row = row
    elseif row.name == "boss_damage_dealt" then
      boss_row = row
    end
    if actual_row and boss_row then
      break
    end
  end
  if not actual_row or not actual_row.data then
    return
  end

  -- Gather entries: player, total damage, 3-letter tag, class icon
  local entries = {}
  for _, player in pairs(Managers.player:players()) do
    if player:is_human_controlled() then
      local id    = player:account_id() or player:name()
      local a     = actual_row.data[id] and actual_row.data[id].score or 0
      local b     = boss_row and boss_row.data and boss_row.data[id] and boss_row.data[id].score or 0
      local total = a + b

      -- three-letter tag
      local tag = string.sub(player:name(), 1, 3)

      -- class icon via their profile archetype
      local icon = ""
      if player._profile and player._profile.archetype and player._profile.archetype.name then
        icon = ICONS[player._profile.archetype.name] or ""
      end

      entries[#entries+1] = {
        total = total,
        tag   = tag,
        icon  = icon
      }
    end
  end

  -- sort by total desc, then tag asc
  table.sort(entries, function(a, b)
    if a.total ~= b.total then
      return a.total > b.total
    else
      return a.tag < b.tag
    end
  end)

  -- assemble parts with shortened values
  local parts = {}
  for _, e in ipairs(entries) do
    local fmt = sb:shorten_value(e.total)
    parts[#parts+1] = string.format("%s%s %s", e.icon, e.tag, fmt)
  end

  -- join with single space (no hyphens)
  local msg = " Dmg Dealt: " .. table.concat(parts, " ")
  Managers.chat:send_channel_message(chan, msg)
  mod._memory.sent_report = true
end

-- Execute on end‐of‐mission cinematic
mod:hook_safe("CinematicSceneExtension", "setup_from_component", function(self)
  local name = self._cinematic_name or ""
  if name == "outro_win" or name == "outro_fail" then
    if cutscene_seen[name] then
      send_scoreboard_damage()
    else
      cutscene_seen[name] = true
    end
  end
end)
